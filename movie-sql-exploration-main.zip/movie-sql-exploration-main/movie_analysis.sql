BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Movies - small dataset for beginners - movies_list" (
	"field1"	TEXT,
	"field2"	TEXT,
	"field3"	TEXT,
	"field4"	TEXT,
	"field5"	TEXT,
	"field6"	TEXT,
	"field7"	TEXT
);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Title','Year','Genre','Director',NULL,'Summary 🎯',NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Casablanca','1942','Romance','Michael Curtiz',NULL,'Total Movies','49');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('12 Angry Men','1957','Drama','Sidney Lumet',NULL,'Total Genres Listed (Unique)','49');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Godfather','1972','Crime','Francis Ford Coppola',NULL,'Total Directors Listed (Unique)','49');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Star Wars: Episode IV - A New Hope','1977','Adventure','George Lucas',NULL,'Movies in the 20th Century (1940-1999)','22');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Alien','1979','Sci-Fi','Ridley Scott',NULL,'Movies in the 2000s (2000-2009)','12');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Empire Strikes Back','1980','Adventure','Irvin Kershner',NULL,'Movies in the 2010s (2010-2019)','15');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Shining','1980','Horror','Stanley Kubrick',NULL,'Total ''Drama'' Movies','10');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Goodfellas','1990','Biography','Martin Scorsese',NULL,'Total ''Sci-Fi'' Movies','6');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Silence of the Lambs','1991','Thriller','Jonathan Demme',NULL,'Total ''Biography'' Movies','4');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Schindler''s List','1993','Biography','Steven Spielberg',NULL,'Total ''Thriller'' Movies','2');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Shawshank Redemption','1994','Drama','Frank Darabont',NULL,'Total ''Crime'' Movies','6');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Pulp Fiction','1994','Crime','Quentin Tarantino',NULL,'Total ''Adventure'' Movies','5');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Forrest Gump','1994','Drama','Robert Zemeckis',NULL,'Total ''Romance'' Movies','2');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Lion King','1994','Animation','Roger Allers & Rob Minkoff',NULL,'Total ''Animation'' Movies','3');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Se7en','1995','Crime','David Fincher',NULL,'Total ''Action'' Movies','7');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Usual Suspects','1995','Crime','Bryan Singer',NULL,'Total ''Western'' Movies','1');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Titanic','1997','Romance','James Cameron',NULL,'Total ''Comedy'' Movies','1');
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Saving Private Ryan','1998','Action','Steven Spielberg',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Truman Show','1998','Drama','Peter Weir',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Fight Club','1999','Drama','David Fincher',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Matrix','1999','Sci-Fi','Lana & Lilly Wachowski',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Green Mile','1999','Drama','Frank Darabont',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Gladiator','2000','Action','Ridley Scott',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Crouching Tiger, Hidden Dragon','2000','Action','Ang Lee',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Lord of the Rings: The Fellowship of the Ring','2001','Adventure','Peter Jackson',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('A Beautiful Mind','2001','Biography','Ron Howard',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Spirited Away','2001','Animation','Hayao Miyazaki',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Lord of the Rings: The Return of the King','2003','Adventure','Peter Jackson',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Prestige','2006','Drama','Christopher Nolan',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Departed','2006','Crime','Martin Scorsese',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('No Country for Old Men','2007','Crime','Joel & Ethan Coen',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Dark Knight','2008','Action','Christopher Nolan',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Avatar','2009','Sci-Fi','James Cameron',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Up','2009','Animation','Pete Docter',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Inception','2010','Sci-Fi','Christopher Nolan',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Social Network','2010','Drama','David Fincher',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Django Unchained','2012','Western','Quentin Tarantino',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Wolf of Wall Street','2013','Biography','Martin Scorsese',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Interstellar','2014','Sci-Fi','Christopher Nolan',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Whiplash','2014','Drama','Damien Chazelle',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Grand Budapest Hotel','2014','Comedy','Wes Anderson',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Mad Max: Fury Road','2015','Action','George Miller',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('The Revenant','2015','Adventure','Alejandro G. Iñárritu',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('La La Land','2016','Musical','Damien Chazelle',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Arrival','2016','Sci-Fi','Denis Villeneuve',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Black Panther','2018','Action','Ryan Coogler',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Joker','2019','Drama','Todd Phillips',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Avengers: Endgame','2019','Action','Anthony & Joe Russo',NULL,NULL,NULL);
INSERT INTO "Movies - small dataset for beginners - movies_list" VALUES ('Parasite','2019','Thriller','Bong Joon-ho',NULL,NULL,NULL);
COMMIT;
