# 🎬  movie-sql-exploration
This beginner-friendly SQL project explores a curated movie dataset using SQLite. It includes queries for:
- Counting total movies
- Grouping by genre and director
- Filtering by year
- Listing unique genres

## 📦 Files Included
- `movies_portfolio.sqlite` – SQLite database
- `queries.sql` – Favorite queries from DB Browser
- `README.md`

## 🛠️ Tech Used
- SQLite via DB Browser
- SQL (SELECT, COUNT, DISTINCT, GROUP BY, ORDER BY)

## 🧠 Learnings
This project helped reinforce:
- How to import CSVs into SQL
- Table/column naming issues and fixes
- Querying techniques

## 🧁 Next Step
We're taking this data into Python soon using `sqlite3`, `pandas`, and `matplotlib` for analysis and visualization.

## View this project on Github:
## [movie_analysis.sql] (https://github.com/BreezeOTM/movie-sql-exploration/blob/main/movie_analysis.sql)
## [movies_portfolio.sqlite.sqbpro] (https://github.com/BreezeOTM/movie-sql-exploration/blob/main/movies_portfolio.sqlite.sqbpro)
